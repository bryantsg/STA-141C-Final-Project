#include <RcppArmadillo.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]
//
// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
// estimate the regression estimates based on given the number of repetitions
//' @useDynLib blblm
//' @importFrom Rcpp sourceCpp
// [[Rcpp::export]]
List lm1cpp(const arma::mat& X, const arma::colvec& y) {
  int n = X.n_rows, k = X.n_cols;
  // fit model y ~ X
  arma::colvec coef = arma::solve(X, y);
  // residuals
  arma::colvec res  = y - X*coef;
  // coefficients std.errors
  double s2 = std::inner_product(res.begin(), res.end(), res.begin(), 0.0)/(n - k);

  arma::colvec std_err = arma::sqrt(s2 * arma::diagvec(arma::pinv(arma::trans(X)*X)));

  return List::create(Named("coef") = coef,
                      Named("stderr") = std_err,
                      Named("rank") = k,
                      Named("residuals") = res);

}
