test_that("model output basic works", {
  fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
  expect_s3_class(fit, "blblm")
  co <- coef(fit)
  expect_equal(length(co), 4)
  fit3 <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, UseCpp = TRUE)
  expect_s3_class(fit3, "blblm")
  co <- coef(fit3)
  expect_equal(length(co), 4)
  fit <- blblm(mpg ~ wt * hp + disp, data = mtcars, m = 2, B = 500)
  expect_s3_class(fit, "blblm")
  co <- coef(fit)
  expect_equal(length(co), 5)
})


test_that("confints works", {

  fit3 <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, UseCpp = TRUE)
  expect_equal(dim(confint(fit3, c("wt","hp"))), c(2,2))
  fit <- blblm(mpg ~ wt * hp + disp, data = mtcars, m = 2, B = 500)
  expect_equal(dim(confint(fit, c("wt","hp","disp"))), c(3,2))


})



test_that("predictions works", {

  fit2 <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
  expect_equal(length(predict(fit2, data.frame(wt = c(2.5, 3), hp = c(150, 170)))), 2)
  expect_equal(dim( predict(fit2, data.frame(wt = c(2.5, 3), hp = c(150, 170)), confidence = TRUE)), c(2,3))

})
