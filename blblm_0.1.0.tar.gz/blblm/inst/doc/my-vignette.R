## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  eval = FALSE,
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#  library(blblm)
#  library(parallel)

## -----------------------------------------------------------------------------
#  fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#  coef(fit)

## -----------------------------------------------------------------------------
#  fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#  coef(fit)

## -----------------------------------------------------------------------------
#  set.seed(1)
#  fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#  coef(fit)

## -----------------------------------------------------------------------------
#  set.seed(1)
#  fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#  coef(fit)

## -----------------------------------------------------------------------------
#  #show confidence intervals of coefficients of wt and hp, default 95%
#  confint(fit, c("wt", "hp"))
#  
#  #show sigma
#  sigma(fit)
#  
#  #show sigma confidence  intervals, , default 95%
#  sigma(fit, confidence = TRUE)
#  
#  
#  #predict mpg using the fitted model on given new data
#  predict(fit, data.frame(wt = c(2.5, 2), hp = c(160, 170)))
#  
#  #predict the same but also show confidence intervals, default 95%
#  predict(fit, data.frame(wt = c(2.5, 2), hp = c(160, 170)), confidence = TRUE)

## -----------------------------------------------------------------------------
#  fit2 <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, parallel = TRUE)
#  coef(fit2)

## -----------------------------------------------------------------------------
#  fit3 <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, UseCpp = TRUE)
#  coef(fit3)

## ----include=FALSE------------------------------------------------------------
#  Sys.setlocale("LC_TIME","C")

## -----------------------------------------------------------------------------
#  set.seed(1)
#  system.time( {
#  blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
#  })
#  system.time( {
#  blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100, UseCpp = TRUE)
#  })

## -----------------------------------------------------------------------------
#  fit4 <- blbglm(cyl ~ wt * hp, family = poisson(), data = mtcars, m = 3, B = 100)
#  coef(fit4)

## -----------------------------------------------------------------------------
#  fit5 <- blbglm(cyl ~ wt * hp, family = poisson(), data = mtcars, m = 3, B = 100, parallel = TRUE)
#  coef(fit5)

## -----------------------------------------------------------------------------
#  #show confidence intervals of coefficients of wt and hp, default 95%
#  confint(fit5, c("wt", "hp"))
#  
#  #show sigma
#  sigma(fit5)
#  
#  #show sigma confidence  intervals, , default 95%
#  sigma(fit5, confidence = TRUE)
#  
#  
#  #predict mpg using the fitted model on given new data
#  predict(fit5, data.frame(wt = c(2.5, 2), hp = c(160, 170)))
#  
#  #predict the same but also show confidence intervals, default 95%
#  predict(fit5, data.frame(wt = c(2.5, 2), hp = c(160, 170)), confidence = TRUE)

