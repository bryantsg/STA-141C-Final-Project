## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(blblm)
library(parallel)


## -----------------------------------------------------------------------------
fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
coef(fit)

## -----------------------------------------------------------------------------
fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
coef(fit)

## -----------------------------------------------------------------------------
set.seed(1)
fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
coef(fit)

## -----------------------------------------------------------------------------
set.seed(1)
fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
coef(fit)

## -----------------------------------------------------------------------------
#show confidence intervals of coefficients of wt and hp, default 95%
confint(fit, c("wt", "hp"))

#show sigma
sigma(fit)

#show sigma confidence  intervals, , default 95%
sigma(fit, confidence = TRUE)


#predict mpg using the fitted model on given new data
predict(fit, data.frame(wt = c(2.5, 2), hp = c(160, 170)))

#predict the same but also show confidence intervals, default 95%
predict(fit, data.frame(wt = c(2.5, 2), hp = c(160, 170)), confidence = TRUE)

